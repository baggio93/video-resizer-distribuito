import os
import time
import uuid
import requests
import subprocess
import shutil

SERVER_URL = "http://127.0.0.1:50123"

def clean_leftover_files():
    print("--- PULIZIA INIZIALE ---")
    files_to_check = ["local_benchmark.mp4", "local_benchmark_out.mp4"]
    for file in os.listdir('.'):
        if file in files_to_check or file.startswith("chunk_in_") or file.startswith("chunk_out_"):
            try:
                os.remove(file)
                print(f"[{time.strftime('%H:%M:%S')}] Rimosso vecchio file residuo: {file}")
            except Exception as e:
                print(f"[{time.strftime('%H:%M:%S')}] Impossibile rimuovere il file {file}: {e}")
    print("Pulizia completata.\n------------------------\n")

def get_server_config():
    """
    Scarica le configurazioni in tempo reale dal server.
    Se fallisce, usa una configurazione sicura di default.
    """
    default_args = ["-vf", "scale=-1:720", "-c:v", "libx264", "-c:a", "copy"]
    try:
        r = requests.get(f"{SERVER_URL}/config", timeout=5)
        if r.status_code == 200:
            config_json = r.json()
            return config_json.get("RESIZE_ARGS", default_args)
    except Exception as e:
        print(f"[{time.strftime('%H:%M:%S')}] Impossibile recuperare impostazioni dal server, uso i default.")
    
    return default_args

def resize_video(input_path, output_path, resize_args):
    print(f"Elaborazione di {input_path} in corso con argomenti: {resize_args}")
    start = time.time()
    subprocess.run(
        ["ffmpeg", "-y", "-i", input_path] + resize_args + [output_path],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
    )
    return time.time() - start

def main():
    clean_leftover_files()
    
    client_id = str(uuid.uuid4())
    print(f"Avvio client con ID univoco: {client_id}")

    # --- FASE 1: Benchmark ---
    print("Download del file di benchmark in corso...")
    try:
        r = requests.get(f"{SERVER_URL}/benchmark", stream=True)
        r.raise_for_status()
    except requests.exceptions.RequestException as e:
        print(f"Impossibile contattare il server per il benchmark: {e}")
        return

    benchmark_input = "local_benchmark.mp4"
    with open(benchmark_input, 'wb') as f:
        for chunk in r.iter_content(chunk_size=8192):
            f.write(chunk)
            
    benchmark_output = "local_benchmark_out.mp4"
    
    # Recupera i parametri dal server appena prima di calcolare il benchmark
    resize_args = get_server_config()
    
    print("Esecuzione del test di benchmark...")
    benchmark_time = resize_video(benchmark_input, benchmark_output, resize_args)
    
    print(f"Benchmark completato in {benchmark_time:.2f} secondi. Invio risultati...")
    requests.post(f"{SERVER_URL}/benchmark_result", json={
        "client_id": client_id,
        "benchmark_time": benchmark_time
    })
    
    if os.path.exists(benchmark_input): os.remove(benchmark_input)
    if os.path.exists(benchmark_output): os.remove(benchmark_output)
    
    # --- FASE 2: Loop di Lavoro ---
    print("Avvio del ciclo di elaborazione distribuita. In attesa di lavoro...")
    while True:
        try:
            r = requests.get(f"{SERVER_URL}/get_chunk", params={"client_id": client_id})
            
            if r.status_code == 404:
                print(f"[{time.strftime('%H:%M:%S')}] Nessun pezzo. Attesa 15 secondi...")
                time.sleep(15)
                continue
            elif r.status_code == 401:
                print(f"Server riavviato: {r.text}")
                time.sleep(5)
                break
            elif r.status_code != 200:
                print(f"Errore recupero chunk: {r.text}")
                time.sleep(5)
                continue
                
            chunk_id = r.headers.get("X-Chunk-Id")
            input_chunk = f"chunk_in_{chunk_id}.mp4"
            output_chunk = f"chunk_out_{chunk_id}.mp4"
            
            with open(input_chunk, 'wb') as f:
                f.write(r.content)
                
            print(f"\n[{time.strftime('%H:%M:%S')}] Inizio elaborazione chunk ID: {chunk_id}...")
            
            # MAGIA: Richiede le configurazioni aggiornate AL VOLO dal server prima di lavorare!
            live_resize_args = get_server_config()
            
            resize_video(input_chunk, output_chunk, live_resize_args)
            
            with open(output_chunk, 'rb') as f:
                res = requests.post(f"{SERVER_URL}/upload_chunk", 
                                  data={"client_id": client_id, "chunk_id": chunk_id},
                                  files={"file": f})
                
            if res.status_code != 200:
                print(f"Attenzione! Upload fallito: {res.text}")
            else:
                print(f"[{time.strftime('%H:%M:%S')}] Chunk {chunk_id} caricato con successo.")
                
            if os.path.exists(input_chunk): os.remove(input_chunk)
            if os.path.exists(output_chunk): os.remove(output_chunk)
                
        except requests.exceptions.RequestException as e:
            print(f"[{time.strftime('%H:%M:%S')}] Errore di connessione: {e}. Ritento...")
            time.sleep(5)
        except Exception as e:
            print(f"[{time.strftime('%H:%M:%S')}] Errore inaspettato: {e}")
            time.sleep(5)
            
if __name__ == "__main__":
    print("--- Configurazione Client Video Resizer ---")
    server_ip = input("Inserisci l'indirizzo IP o hostname del server (predefinito 127.0.0.1): ").strip() or "127.0.0.1"
    server_port = input("Inserisci la porta del server (predefinita 50123): ").strip() or "50123"
    SERVER_URL = f"http://{server_ip}:{server_port}"
    main()
